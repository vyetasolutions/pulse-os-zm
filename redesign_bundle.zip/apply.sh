#!/bin/bash
set -e
echo "== Applying redesigned LandingStats =="
mkdir -p src/components
cp -f LandingStats.jsx src/components/LandingStats.jsx
echo "Done: src/components/LandingStats.jsx"
echo ""
echo "REMINDER: manually add the Google Fonts <link> tags to index.html <head> —"
echo "this script does not touch index.html since it's a shared file."

import { useEffect, useState } from 'react'
import {
  PieChart, Pie, Cell, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis
} from 'recharts'
import {
  fetchPlatformSummary,
  fetchConstituencyLeaderboard,
  fetchTrendingIssues,
  relativeTime
} from '../lib/accountability'

const COLORS = ['#f97316', '#fde8d3'] // warm orange, soft peach — less "corporate indigo"

const statusEmoji = {
  pending: '🟡',
  acknowledged: '👀',
  in_progress: '🔧',
  resolved: '✅',
  reopened: '🔁',
  closed_duplicate: '⚪'
}

export default function LandingStats() {
  const [summary, setSummary] = useState(null)
  const [leaderboard, setLeaderboard] = useState([])
  const [trending, setTrending] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([fetchPlatformSummary(), fetchConstituencyLeaderboard(), fetchTrendingIssues()])
      .then(([s, l, t]) => {
        setSummary(s)
        setLeaderboard(l)
        setTrending(t)
      })
      .catch(() => {
        setSummary(null)
        setLeaderboard([])
        setTrending([])
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) {
    return <div className="text-xs text-slate-400 text-center py-6">Loading...</div>
  }

  if (!summary) return null

  const pendingCount = Math.max(summary.total_issues - summary.resolved_count, 0)
  const donutData = [
    { name: 'Fixed', value: summary.resolved_count },
    { name: 'In progress', value: pendingCount }
  ]
  const activeConstituencies = leaderboard.filter((c) => c.total_issues > 0).slice(0, 5)

  return (
    <div className="px-4 pt-5 pb-2 space-y-4 max-w-sm mx-auto">
      {/* Stat pills — horizontal scroll on mobile instead of a cramped grid */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 no-scrollbar">
        <Pill label="Requests" value={summary.total_issues} emoji="📋" />
        <Pill label="Fixed" value={summary.resolved_count} emoji="✅" />
        <Pill label="Response" value={`${summary.resolution_rate_pct}%`} emoji="⚡" />
        <Pill label="Attention" value={summary.overdue_count} emoji="🔔" warn={summary.overdue_count > 0} />
      </div>

      {/* Trending feed — the "alive" part */}
      {trending.length > 0 ? (
        <div className="bg-white rounded-3xl border border-slate-100 p-4 shadow-sm">
          <h3 className="text-xs font-black text-slate-800 mb-3 flex items-center gap-1.5">
            🔥 Happening in your community
          </h3>
          <div className="space-y-2.5">
            {trending.map((issue) => (
              <div key={issue.id} className="flex items-center gap-2.5">
                <span className="text-lg leading-none">{issue.issue_categories?.icon || '📍'}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-700 truncate">
                    {issue.issue_categories?.label || issue.category} · {issue.constituencies?.name}
                  </p>
                  <p className="text-[10px] text-slate-400">{relativeTime(issue.created_at)}</p>
                </div>
                <span className="text-sm">{statusEmoji[issue.status] || '•'}</span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <EmptyState
          title="Be the first to try it out"
          subtitle="Let your local office know what needs fixing — it only takes a minute."
        />
      )}

      {/* Donut — compact, rounded card, warm palette */}
      {summary.total_issues > 0 && (
        <div className="bg-white rounded-3xl border border-slate-100 p-4 shadow-sm flex items-center gap-4">
          <div className="w-20 h-20 shrink-0">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={donutData} dataKey="value" innerRadius={26} outerRadius={38} paddingAngle={3}>
                  {donutData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="text-xs space-y-1">
            <p className="font-bold text-slate-700 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-orange-500 inline-block" /> {summary.resolved_count} fixed
            </p>
            <p className="font-bold text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-orange-100 inline-block" /> {pendingCount} in progress
            </p>
          </div>
        </div>
      )}

      {/* Top offices — celebratory framing, horizontal bars kept small for mobile */}
      {activeConstituencies.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-100 p-4 shadow-sm">
          <h3 className="text-xs font-black text-slate-800 mb-3">🏆 Top Performing Offices</h3>
          <div className="w-full h-40">
            <ResponsiveContainer>
              <BarChart data={activeConstituencies} layout="vertical" margin={{ left: 0, right: 10 }}>
                <XAxis type="number" hide domain={[0, 100]} />
                <YAxis
                  type="category"
                  dataKey="constituency_name"
                  width={80}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 10, fontWeight: 700, fill: '#475569' }}
                />
                <Bar dataKey="resolution_rate_pct" fill="#f97316" radius={[0, 8, 8, 0]} barSize={14} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  )
}

function Pill({ label, value, emoji, warn }) {
  return (
    <div className={`shrink-0 flex items-center gap-2 rounded-full px-3.5 py-2 border ${
      warn && value > 0 ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-100'
    }`}>
      <span className="text-sm">{emoji}</span>
      <div>
        <p className="text-sm font-black text-slate-800 leading-none">{value}</p>
        <p className="text-[9px] font-bold text-slate-400 uppercase leading-none mt-0.5">{label}</p>
      </div>
    </div>
  )
}

function EmptyState({ title, subtitle }) {
  return (
    <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-6 text-center">
      <p className="text-sm font-bold text-slate-700 mb-1">{title}</p>
      <p className="text-xs text-slate-400">{subtitle}</p>
    </div>
  )
}

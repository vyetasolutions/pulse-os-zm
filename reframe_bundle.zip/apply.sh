#!/bin/bash
set -e
echo "== Applying reframe + mobile optimization =="
mkdir -p src/components src/pages src/lib
cp -f AuthScreen.jsx src/components/AuthScreen.jsx
cp -f StaffDashboard.jsx src/pages/StaffDashboard.jsx
cp -f LandingStats.jsx src/components/LandingStats.jsx
cp -f accountability.js src/lib/accountability.js
echo ""
echo "== Files updated =="
echo "src/components/AuthScreen.jsx"
echo "src/pages/StaffDashboard.jsx"
echo "src/components/LandingStats.jsx"
echo "src/lib/accountability.js"
echo ""
echo "REMINDER: run public_issues_policy.sql in the Supabase SQL editor manually —"
echo "this script cannot run SQL for you."

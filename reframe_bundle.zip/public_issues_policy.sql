-- Allows anonymous (pre-login) visitors to see non-incognito issues,
-- for the "trending in your community" landing page feed.
-- Incognito reports remain hidden regardless of auth state.
-- This does not expose reporter identity — join against profiles separately
-- if needed, gated by the existing profiles_select_public_basic policy.

create policy issues_select_public_anon on issues for select
  using (is_incognito = false);

-- Note: this policy is additive (RLS policies are OR'd together), so it
-- doesn't loosen anything for logged-in users — it only adds anonymous read
-- access to the same non-incognito rows that were already publicly visible
-- to logged-in citizens.
